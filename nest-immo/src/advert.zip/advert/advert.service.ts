import { Injectable } from '@nestjs/common';
import { CreateAdvertDto } from './dto/create-advert.dto';
import { UpdateAdvertDto } from './dto/update-advert.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { AdvertEntity } from './entities/advert.entity';
import { QueriesAdvertDTO } from './dto/queries-advert.dto';

@Injectable()
export class AdvertService {
  constructor(
    @InjectRepository(AdvertEntity)
    private readonly advertRepository: Repository<AdvertEntity>,
  ) {}

  create(createAdvertDto: CreateAdvertDto) {
    try {
      return this.advertRepository.save(createAdvertDto);
    } catch (error) {
      throw new Error(error);
    }
  }

  findAll(queries: QueriesAdvertDTO) {
    console.log(queries);
    let max_price: number
    let min_rooms: number
    //convert int
    if (queries.max_price) max_price = parseInt(queries.max_price);
    if (queries.min_rooms) min_rooms = parseInt(queries.min_rooms);

    //select * from advert where price <= max_price and nb_rooms >= min_rooms
    return this.advertRepository.createQueryBuilder("advert")
      .where("advert.price <= :max_price", { max_price })
      .andWhere("advert.nb_rooms >= :min_rooms", { min_rooms })
      .getMany();
    
  }

  findOne(id: number) {
    return this.advertRepository.findOneBy({id: id});
  }

  update(id: number, updateAdvertDto: UpdateAdvertDto) {
    return this.advertRepository.update(id, updateAdvertDto);
  }

  remove(id: number) {
    return this.advertRepository.softDelete(id);
  }
}
