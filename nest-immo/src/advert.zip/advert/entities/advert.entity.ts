import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";
import { TimestampEntity } from '../../generic/timestamp.entity';
@Entity("advert")
export class AdvertEntity extends TimestampEntity {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    title: string;
    
    @Column()
    description: string;

    @Column()
    price: number;

    @Column()
    nb_rooms: number;
}
