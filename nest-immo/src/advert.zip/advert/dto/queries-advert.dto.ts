export class QueriesAdvertDTO {
    max_price: string;
    min_rooms: string;
}