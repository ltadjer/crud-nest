export class CreateAdvertDto {
    title: string;
    description: string;
    price: number;
    nb_rooms: number;
}
